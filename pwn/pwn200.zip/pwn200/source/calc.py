from __future__ import print_function
import sys

banner="""
 _____________________
|  _________________  |
| | JO           0. | |
| |_________________| |
|  ___ ___ ___   ___  |
| | 7 | 8 | 9 | | + | |
| |___|___|___| |___| |
| | 4 | 5 | 6 | | - | |
| |___|___|___| |___| |
| | 1 | 2 | 3 | | x | |
| |___|___|___| |___| |
| | . | 0 | = | | / | |
| |___|___|___| |___| |
|_____________________|"""

print(banner)
print("------------------------")
blacklist = ["import","os","exec","subprocess","fl4g","input","pickle","print","open"]

print("LOL Calculator\n")

while 1:
	sys.stdout.write("_> ")
	data=raw_input()
	for i in blacklist:
		data=data.replace(i,"x")

	try:
		print(eval(data))
	
	except:
    		print('An error occurred.')
