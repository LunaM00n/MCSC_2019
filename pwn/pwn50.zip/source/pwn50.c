#include <stdio.h>
#include <string.h>

int main() {
	int ctf;
	char buf[50];

	gets(buf);
	printf("buf: %08x = %s ctf: %08x\n = %i\n", &buf, buf, &ctf, ctf);

	if (ctf == 0x4353434d)
		system("cat fl4g");
}


