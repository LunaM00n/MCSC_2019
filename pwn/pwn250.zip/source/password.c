#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

struct password {
	void (*printpassword)();
	char *content ;
};

struct password *passwordlist[5];
int count = 0;

void show_password_content(struct password *this){
	puts(this->content);
}
void save_password(){
	int i ;
	char buf[8];
	int size ;
	if(count > 5){
		puts("Not enough storage!");
		return ;
	}
	for(i = 0 ; i < 5 ; i ++){
		if(!passwordlist[i]){
			passwordlist[i] = (struct password*)malloc(sizeof(struct password));
			if(!passwordlist[i]){
				puts("Allocation Error");
				exit(-1);
			}
			passwordlist[i]->printpassword = show_password_content;
			printf("password size :");
			read(0,buf,8);
			size = atoi(buf);
			passwordlist[i]->content = (char *)malloc(size);
			if(!passwordlist[i]->content){
				puts("Allocation Error");
				exit(-1);
			}
			printf("Content :");
			read(0,passwordlist[i]->content,size);
			puts("Saved");
			count++;
			break;
		}
	}
}

void del_password(){
	char buf[4];
	int idx ;
	printf("Index :");
	read(0,buf,4);
	idx = atoi(buf);
	if(idx < 0 || idx >= count){
		puts("Out of range");
		_exit(0);
	}
	if(passwordlist[idx]){
		free(passwordlist[idx]->content);
		free(passwordlist[idx]);
		puts("Deleted");
	}
}

void show_password(){
	char buf[4];
	int idx ;
	printf("Index :");
	read(0,buf,4);
	idx = atoi(buf);
	if(idx < 0 || idx >= count){
		puts("Out of range");
		_exit(0);
	}
	if(passwordlist[idx]){
		passwordlist[idx]->printpassword(passwordlist[idx]);
	}
}

void get_flag(){
	system("cat fl4g");
}


void menu(){
	puts("----------------------");
	puts("       Main Menu      ");	
	puts("----------------------");
	puts(" 1. Save new password ");
	puts(" 2. Remove password   ");
	puts(" 3. View password     ");
	puts(" 4. Exit              ");
	puts("----------------------");
	printf("Enter :");
};

int main(){
	setvbuf(stdout,0,2,0);
	setvbuf(stdin,0,2,0);
	char buf[4];
	while(1){
		menu();
		read(0,buf,4);
		switch(atoi(buf)){
			case 1 :
				save_password();
				break ;
			case 2 :
				del_password();
				break ;
			case 3 :
				show_password();
				break ;
			case 4 :
				exit(0);
				break ;
			default :
				puts("Choose the right one");
				break ;

		}
	}
	return 0;
}

