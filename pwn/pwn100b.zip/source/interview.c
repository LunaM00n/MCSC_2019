#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int question()
{
	char name[30];
	printf("What is your name :");
	gets(name);
	printf("Your name is : %s\n",name);
	return 0;
}

int banner()
{
	printf("Interview with MCSC 2019\n");
	return 0;
}

void get_flag()
{
	system("cat fl4g");
}

void menu(){
	puts("----------------------");
	puts("       Interview      ");	
	puts("----------------------");
	puts(" 1. Questions         ");
	puts(" 2. Banner            ");
	puts(" 3. Exit              ");
	puts("----------------------");
};

int main()
{
	char buf[4];
	while(1)
	{
		menu();
		read(0,buf,4);
		switch(atoi(buf))
		{
			case 1:
				question();
				break;
			case 2:
                                banner();
                                break;
			case 3:
                                exit(0);
                                break;
			default :
                                printf("Invalid Choice");
                                break;
		}
	}
	return 0;
}
