<h1>MCSC 2019 Web 200 - RCE</h1>
<p>Read the fl4g.</p>

<a href='index.php?lol=O:3:"LOL":3:{s:4:"auth";i:1;s:6:"secret";i:2;s:7:"service";s:4:"Luna";}'>Try !</a>

<p>source code </p>
<pre>
$secret = random_value;
if($auth===$secret)
{
	eval($service);
}
</pre>

<?php

class LOL
{
	public $auth;
	public $secret;
	public $service;
}


$obj=unserialize($_GET['lol']);

echo "[ auth = ".$obj->auth." ]<br>";
echo "[ secret = ".$obj->secret." ]<br>";
echo "[ service = ".$obj->service." ]<br>";

if($obj)
{
	$obj->secret=rand(1,9999);
	if($obj->auth === $obj->secret)
	{
		eval("echo 'Hello ".$obj->service."!!!';");
	}
	else
	{
		echo "Failed to call service.<br>";
	}
}

?>
