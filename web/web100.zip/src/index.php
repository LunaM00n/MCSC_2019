<h1>MCSC 2019 Web 100</h1>
 <p>Strings are not only to print. Find the file named "fl4g".</p>

<form action="" method="POST">
	<input type="hidden" name="string1">
	<input type="text" name="string2">
	<input type="submit" name="submit" value="print">
</form>

<?php 

ini_set('display_errors',1);
error_reporting(E_ALL);

if (isset($_POST['submit'])) {
	$str1=@(string)$_POST['string1'];
	$str2=@(string)$_POST['string2'];
	eval('$str="'.addslashes($str1).'";');
	echo "Hello ".htmlspecialchars($str2)." !!!";
}

 ?>
