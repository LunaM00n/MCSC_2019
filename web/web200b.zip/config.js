var config={};

config.password="mcsc2019";
config.flag=["MCSC_2019{n0d3_j5_m3m0ry_L3ak}"];

module.exports = config;
