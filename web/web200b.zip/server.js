var express = require('express');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('cookie-session');
var config = require('./config');
var fs = require('fs');
var app = express();

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.use(session({
	name:'session',
	keys:config.flag,
	cookie: {secure:true}
	})
);

app.use(function (req,res,next){
	if(req.session.admin === undefined ){
	req.session.admin='no';
	}
	next();
});

var sess;

app.get('/',function(req,res,next){
	res.send(fs.readFileSync(__filename).toString());
});

app.post('/login', function(req, res, next) {
	if(req.body.password)
	{
        	var password = new Buffer(req.body.password);
		if(password == config.password){
			req.session.admin = 'yes';
			res.redirect('/');
		}
		else {
        		res.json({'status': 'error', 'error': 'password wrong: '+password.toString() });
		}
	}
	else{
		res.send(fs.readFileSync(__filename).toString());
	}
});

app.listen(3000,'0.0.0.0');
console.log("Listening on port 3000");
